# Hidden Eden — partial formalization

THIS IS NOT A FORMAL PROOF OF A COUNTEREXAMPLE TO KUZNETSOV–EDEN.

Verified with Lean 4.33.1 (commit 819816b2e0a3bf405af45ae5c7af2491d8f5bee6).
Mathlib is pinned to 0df444a360eaa60ab8c11dca51a86af692955474,
the Mathlib v4.33.1 release, whose toolchain is leanprover/lean4:v4.33.1.

This update changes the compiler and compatible dependency versions.
The scope and limitations of the partial formalization are unchanged.

## Reproduce

With elan installed, extract this archive and run in its directory:

    lake update
    lake exe cache get
    lake env lean HiddenEdenPartial.lean

The toolchain file selects the compiler and the Lake configuration pins Mathlib.
The source was compiled successfully using these exact compiler and Mathlib
versions, with no errors or warnings. The compiler's axiom report is included.
The local verification used package paths for the downloaded dependencies;
those environment-specific paths are not needed for the commands above.

## What Lean checks

* The integral functional is at most 7/2 for nonnegative q.
* It equals 7/2 on an invariant zero set.
* It is strictly less outside that zero set under continuity assumptions.
* Each compact invariant set on which q is positive has a uniform positive gap.
* The proposed four leading exponents are ordered and their sums cross zero at 3.
* The corresponding algebraic Kaplan–Yorke branch equals 7/2 - b/lam.
* Given a nonempty aperiodic invariant zero set, no periodic point maximizes
  the scalar functional.

These are conditional analytic results about a scalar functional. No `sorry`
or added axiom is used. The axiom report contains only Mathlib's standard
propext, Classical.choice and Quot.sound foundations.

## What Lean DOES NOT check

It does not construct the cat-map suspension, prove its dynamical properties,
construct the compact aperiodic invariant set or a smooth function with that
zero set, prove the required smooth Nash embedding, construct and differentiate
the normal-bundle flow, prove the complete global ODE and hidden basin, or
identify the scalar functional with ambient singular-value Lyapunov dimension.
It also does not prove the asymptotic or uniform set dimension assertion.
Those are essential mathematical steps, not compiler compatibility issues.

The final block comment preserves the ENTIRE previous informal argument.
Lean ignores that comment. Its inclusion is not evidence of formal verification,
correctness, novelty, or a resolution of the historical conjecture.
